Backend node --test packages/web/server/lib/acp/*.test.js
exit=1
tests=18 pass=17 fail=1 skipped=0 todo=0
failure: elicitation.test.js HTTP snapshot and SSE recover a blocked form with its original request ID; ACP initialize timed out

Build/publish node --test scripts/acp-build.test.mjs scripts/publish-acp.test.mjs scripts/build-personal.test.mjs packages/electron/personal-updates.test.mjs
exit=0
tests=17 pass=17 fail=0 skipped=0 todo=0

All launched test processes completed. Logs are in .codex-temp/acp-closure-backend.log and .codex-temp/acp-closure-build.log.
