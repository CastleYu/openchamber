import { readFile } from 'node:fs/promises';
import { createAcpRuntime } from '../packages/web/server/lib/acp/runtime.js';
const root='D:/CodexBuilds/acp-real-validation/opencode-test';
Object.assign(process.env,{XDG_DATA_HOME:root+'/data',XDG_CONFIG_HOME:root+'/config',XDG_CACHE_HOME:root+'/cache',XDG_STATE_HOME:root+'/state',TEMP:root+'/temp',TMP:root+'/temp',OPENCODE_DISABLE_AUTOUPDATE:'true',OPENCODE_CONFIG_CONTENT:JSON.stringify({plugin:[]})});
const runtime=createAcpRuntime();
try{
 await runtime.start({command:'C:/nvm4w/nodejs/node_modules/opencode-ai/bin/opencode.exe',args:['--pure','acp'],cwd:root+'/workspace'});
 const id=JSON.parse(await readFile(root+'/results.json','utf8')).checks[0].ids[0];
 const scope=(root+'/workspace/').replace(/^D:/,'d:');
 const found=await runtime.discover(scope);
 if(!found.some(s=>s.id===id))throw Error('Scoped discovery did not import expected history');
 await runtime.open(id);
 const messages=runtime.messages(id);
 if(!messages.some(m=>m.parts.some(p=>p.type==='text'&&p.text.includes('ALPHA_718'))))throw Error('History marker missing');
 console.log(JSON.stringify({test:'scoped-discovery-after-fix',pass:true,scope,sessions:found.length,messages:messages.length,readOnly:runtime.session(id).readOnly}));
}finally{await runtime.stop();console.log('AGENT_STOPPED');}
