import { mkdir, writeFile, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createAcpRuntime } from '../packages/web/server/lib/acp/runtime.js';

const root = 'D:/CodexBuilds/acp-real-validation/opencode-test';
for (const dir of ['workspace', 'data', 'config', 'cache', 'state', 'temp']) await mkdir(join(root, dir), { recursive: true });
Object.assign(process.env, { XDG_DATA_HOME: join(root,'data'), XDG_CONFIG_HOME: join(root,'config'), XDG_CACHE_HOME: join(root,'cache'), XDG_STATE_HOME: join(root,'state'), TEMP: join(root,'temp'), TMP: join(root,'temp'), OPENCODE_DISABLE_AUTOUPDATE:'true' });
process.env.OPENCODE_CONFIG_CONTENT = JSON.stringify({model:`openai/${process.env.OPENAI_MODEL}`, provider:{openai:{options:{baseURL:process.env.OPENAI_BASE_URL,apiKey:'{env:OPENAI_API_KEY}'},models:{[process.env.OPENAI_MODEL]:{name:process.env.OPENAI_MODEL}}}},permission:{'*':'ask'},plugin:[]});
const cwd = join(root,'workspace');
await writeFile(join(cwd,'seed.txt'),'ACP_REAL_SEED_7341\n');
const selection = {command:'C:/nvm4w/nodejs/node_modules/opencode-ai/bin/opencode.exe',args:['--pure','acp'],cwd};
const storagePath = join(root,'sessions.json');
let runtime = createAcpRuntime({storagePath});
const report = {agent:'OpenCode',model:process.env.OPENAI_MODEL,checks:[]};
let policy = 'allow_once';
let approvals = [];
const attach = () => runtime.subscribe(event => {
  if (event.type === 'permission-asked') {
    const request=event.request.value;
    approvals.push({sessionID:request.sessionID,options:request.options});
    console.log(JSON.stringify({event:'permission',sessionID:request.sessionID,options:request.options.map(x=>({id:x.optionId,kind:x.kind}))}));
    if(policy !== 'hold') { const option=request.options.find(x=>x.kind===policy); if(option) void runtime.reply(request.id,option.optionId); }
  }
  if(event.type==='status') console.log(JSON.stringify({event:'status',sessionID:event.sessionID,outcome:event.outcome,error:event.error}));
});
const wait = async (predicate,timeout=90000) => {const start=Date.now();while(!predicate()){if(Date.now()-start>timeout)throw Error('Timed out waiting for real agent');await new Promise(r=>setTimeout(r,100));}};
const turn = async(id,text) => {await runtime.prompt({sessionID:id,messageID:crypto.randomUUID(),text});await wait(()=>runtime.statuses()[id]?.type==='idle');const messages=runtime.messages(id);const answer=messages.at(-1);if(answer.info.error)throw Error(answer.info.error.message);return answer;};
const record = (name,data) => {report.checks.push({name,...data}); console.log(JSON.stringify(report.checks.at(-1)));};
try {
 attach();await runtime.start(selection); report.info=runtime.info(); console.log(JSON.stringify({info:report.info}));
 const a=await runtime.createSession({directory:cwd,title:'Real A'}); const b=await runtime.createSession({directory:cwd,title:'Real B'});
 record('multi-session-create',{pass:a.id!==b.id,ids:[a.id,b.id]});
 const responses=await Promise.all([turn(a.id,'Remember private marker ALPHA_718. Reply only ALPHA_718, without tools.'),turn(b.id,'Remember private marker BETA_629. Reply only BETA_629, without tools.')]);
 record('concurrent-prompts',{answers:responses.map(x=>x.parts.filter(p=>p.type==='text').map(p=>p.text).join(''))});
 const tool=await turn(a.id,'Read seed.txt using a file tool. Then create result.txt containing exactly ACP_WRITE_7341 using a file edit tool. Do not use shell. Report the seed contents.');
 record('tools-and-approval',{tools:tool.parts.filter(x=>x.type==='tool'),approvals:approvals.length,file:await readFile(join(cwd,'result.txt'),'utf8')});
 policy='hold';const before=approvals.length;await runtime.prompt({sessionID:b.id,messageID:crypto.randomUUID(),text:'Create cancel-target.txt with text SHOULD_NOT_EXIST using your file edit tool. Do not ask a question; call the tool.'});await wait(()=>approvals.length>before);await runtime.cancel(b.id);await wait(()=>runtime.statuses()[b.id]?.type==='idle');record('cancel-pending-approval',{pending:runtime.permissions().length,status:runtime.statuses()[b.id],error:runtime.messages(b.id).at(-1).info.error});
 policy='allow_once';const beforeCount=runtime.messages(a.id).length;await runtime.stop();runtime=createAcpRuntime({storagePath});attach();await runtime.start(selection);await runtime.open(a.id);record('history-restore',{beforeCount,afterCount:runtime.messages(a.id).length,readOnly:runtime.session(a.id).readOnly});
 const restored=await turn(a.id,'What was the private marker I told you earlier? Reply only that marker. Do not inspect files.');record('history-continuation',{answer:restored.parts.filter(x=>x.type==='text').map(x=>x.text).join('')});
}catch(error){report.error=error.message;console.log(JSON.stringify({error:error.message}));process.exitCode=1;}finally{await runtime.stop();await writeFile(join(root,'results.json'),JSON.stringify(report,null,2));console.log('AGENT_STOPPED');}
