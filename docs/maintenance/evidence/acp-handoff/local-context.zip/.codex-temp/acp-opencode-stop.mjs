import { readFile, writeFile, access } from 'node:fs/promises';
import { createAcpRuntime } from '../packages/web/server/lib/acp/runtime.js';
const root='D:/CodexBuilds/acp-real-validation/opencode-test';
Object.assign(process.env,{XDG_DATA_HOME:root+'/data',XDG_CONFIG_HOME:root+'/config',XDG_CACHE_HOME:root+'/cache',XDG_STATE_HOME:root+'/state',TEMP:root+'/temp',TMP:root+'/temp',OPENCODE_DISABLE_AUTOUPDATE:'true'});
process.env.OPENCODE_CONFIG_CONTENT=JSON.stringify({model:`openai/${process.env.OPENAI_MODEL}`,provider:{openai:{options:{baseURL:process.env.OPENAI_BASE_URL,apiKey:'{env:OPENAI_API_KEY}'},models:{[process.env.OPENAI_MODEL]:{name:process.env.OPENAI_MODEL}}}},permission:{'*':'ask'},plugin:[]});
const runtime=createAcpRuntime({storagePath:root+'/imported-sessions.json'});
const wait=async(fn,ms=90000)=>{const start=Date.now();while(!fn()){if(Date.now()-start>ms)throw Error('Real agent timeout');await new Promise(r=>setTimeout(r,100));}};
let policy='reject_once';let permissionCount=0;const statuses=[];
runtime.subscribe(e=>{if(e.type==='status')statuses.push(e);if(e.type==='permission-asked'){permissionCount++;const p=e.request.value;const o=p.options.find(o=>o.kind===policy);if(o)void runtime.reply(p.id,o.optionId);}});
try{
 await runtime.start({command:'C:/nvm4w/nodejs/node_modules/opencode-ai/bin/opencode.exe',args:['--pure','acp'],cwd:root+'/workspace'});
 const previous=JSON.parse(await readFile(root+'/results.json','utf8')).checks[0].ids[0];
 await runtime.discover(root+'/workspace');console.log(JSON.stringify({test:'scoped-discovery',sessions:runtime.sessions()}));await runtime.discover();console.log(JSON.stringify({test:'unscoped-discovery',sessions:runtime.sessions().map(s=>({id:s.id,directory:s.directory}))}));await runtime.open(previous);
 console.log(JSON.stringify({test:'agent-history-import',sessions:runtime.sessions().length,messages:runtime.messages(previous).length,text:runtime.messages(previous).flatMap(m=>m.parts.filter(p=>p.type==='text').map(p=>p.text)).join('\n').includes('ALPHA_718')}));
 const s=await runtime.createSession({directory:root+'/workspace',title:'Stop and rejection'});
 await runtime.prompt({sessionID:s.id,messageID:crypto.randomUUID(),text:'Create denied.txt containing DENIED using an edit tool. If permission is rejected, stop; do not retry or use another tool.'});await wait(()=>runtime.statuses()[s.id]?.type==='idle');
 console.log(JSON.stringify({test:'permission-rejection',permissionCount,fileExists:await access(root+'/workspace/denied.txt').then(()=>true,()=>false)}));
 policy='allow_once';await runtime.prompt({sessionID:s.id,messageID:crypto.randomUUID(),text:'Use your shell tool to run exactly: node -e "require(\'fs\').writeFileSync(\'running.pid\',String(process.pid));setTimeout(()=>require(\'fs\').writeFileSync(\'too-late.txt\',\'BAD\'),60000)". Wait for it to finish. Do not use background execution.'});
 let pid;const start=Date.now();while(!pid){try{pid=Number(await readFile(root+'/workspace/running.pid','utf8'));}catch{}if(Date.now()-start>90000)throw Error('Shell did not start');await new Promise(r=>setTimeout(r,100));}
 const before=Date.now();await runtime.cancel(s.id);await wait(()=>runtime.statuses()[s.id]?.type==='idle',20000);await wait(()=>{try{process.kill(pid,0);return false;}catch{return true;}},10000);
 console.log(JSON.stringify({test:'cancel-running-shell',pid,elapsedMs:Date.now()-before,processExited:true,pending:runtime.permissions().length,lateFile:await access(root+'/workspace/too-late.txt').then(()=>true,()=>false),outcome:statuses.at(-1).outcome}));
}catch(e){console.log(JSON.stringify({error:e.message}));process.exitCode=1;}finally{await runtime.stop();console.log('AGENT_STOPPED');}
