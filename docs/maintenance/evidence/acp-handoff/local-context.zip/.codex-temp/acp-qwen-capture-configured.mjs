import { spawn } from 'node:child_process';
import { appendFileSync } from 'node:fs';
import { createInterface } from 'node:readline';

const logPath = 'D:/CodexBuilds/acp-real-validation/qwen-configured-diagnostic.log';
const secrets = Object.entries(process.env).filter(([name, value]) => value && /KEY|TOKEN|PASSWORD|SECRET/i.test(name)).map(([, value]) => value);
const redact = (text) => secrets.reduce((value, secret) => value.replaceAll(secret, '[redacted]'), text);
const child = spawn(process.execPath, ['D:/CodexBuilds/acp-real-validation/qwen/node_modules/@qwen-code/qwen-code/cli-entry.js', ...process.argv.slice(2)], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
process.stdin.pipe(child.stdin);
child.stdout.pipe(process.stdout);
createInterface({ input: child.stderr }).on('line', (line) => appendFileSync(logPath, `${redact(line)}\n`));
createInterface({ input: child.stdout }).on('line', (line) => {
  try {
    const message = JSON.parse(line);
    if (message.error) appendFileSync(logPath, `${redact(JSON.stringify(message.error))}\n`);
  } catch {}
});
child.on('exit', (code) => process.exit(code ?? 1));
