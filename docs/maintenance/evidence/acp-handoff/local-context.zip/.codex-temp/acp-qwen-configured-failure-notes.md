# Qwen ACP configured acceptance command notes

- 2026-10-14: PowerShell in the current workspace sandbox could read `D:/CodexBuilds/acp-real-validation/qwen-real-run.json`, but `Copy-Item` to the same test directory was denied and Node received `EPERM` when creating `qwen-configured-run.json`. The failed source JSON remains unchanged. Retry the exact scoped copy and acceptance command with the approved elevated sandbox; do not redirect or print `OPENCODE_GO_API_KEY`.
