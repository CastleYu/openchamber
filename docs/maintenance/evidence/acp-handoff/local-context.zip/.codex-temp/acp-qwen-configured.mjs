import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createAcpRuntime } from '../packages/web/server/lib/acp/runtime.js';

const root = 'D:/CodexBuilds/acp-real-validation';
const home = join(root, 'qwen-configured-test');
const workspace = join(home, 'workspace');
const output = join(root, 'qwen-configured-run.json');
const cli = join(root, 'qwen/node_modules/@qwen-code/qwen-code/cli-entry.js');
const log = [];
const result = { agent: 'Qwen Code', version: '0.25.1', model: 'deepseek-v4-flash', api: 'OpenCode Go', tests: {}, errors: [] };
const note = (key, value) => { result.tests[key] = value; log.push({ key, value }); };
const waitFor = (runtime, predicate, timeout = 60000) => new Promise((resolveEvent, reject) => {
  const timer = setTimeout(() => { off(); reject(new Error(`timeout after ${timeout}ms`)); }, timeout);
  const off = runtime.subscribe((event) => {
    if (!predicate(event)) return;
    clearTimeout(timer); off(); resolveEvent(event);
  });
});
const done = (runtime, sessionID, timeout = 60000) => waitFor(runtime,
  (event) => event.type === 'status' && event.sessionID === sessionID && ['completed', 'interrupted', 'failed'].includes(event.outcome), timeout);
const outcome = (event) => ({ outcome: event.outcome, error: event.error?.message ?? null });
const textOf = (runtime, id) => runtime.messages(id).flatMap((message) => message.parts).filter((part) => part.type === 'text').map((part) => part.text).join('');
const runtime = createAcpRuntime({ storagePath: join(home, 'acp-sessions.json') });
let stopCalled = false;
let started = false;
try {
  await mkdir(join(workspace, 'temp'), { recursive: true });
  Object.assign(process.env, { QWEN_HOME: home, HOME: home, USERPROFILE: home, TEMP: join(workspace, 'temp'), TMP: join(workspace, 'temp') });
  if (!process.env.OPENCODE_GO_API_KEY) throw new Error('OPENCODE_GO_API_KEY was not injected into the test process');
  await writeFile(join(home, 'settings.json'), JSON.stringify({
    security: { auth: { selectedType: 'openai' } },
    outboundCorrelation: { allowDynamicHeaderValues: true },
    model: { name: process.env.OPENAI_MODEL || 'deepseek-v4-flash' },
    modelProviders: { openai: [{
      id: process.env.OPENAI_MODEL || 'deepseek-v4-flash', name: 'OpenCode Go acceptance', envKey: 'OPENCODE_GO_API_KEY',
      baseUrl: 'https://opencode.ai/inference/go/v1',
      generationConfig: { customHeaders: { 'x-opencode-session': '${session_id}' } },
    }] },
  }, null, 2), 'utf8');
  const start = async () => runtime.start({ command: process.execPath, args: [join(process.cwd(), '.codex-temp/acp-qwen-capture-configured.mjs'), '--acp', '--approval-mode', 'default', '--safe-mode'], cwd: workspace });
  const connected = await start(); started = true;
  note('initialize', { version: connected.version, agentInfo: runtime.info().agentInfo, agentCapabilities: runtime.info().agentCapabilities });
  const a = await runtime.createSession({ directory: workspace, title: 'Configured A' });
  const b = await runtime.createSession({ directory: workspace, title: 'Configured B' });
  note('multi_session', { idsDistinct: a.id !== b.id });

  const aDone = done(runtime, a.id);
  const bDone = done(runtime, b.id);
  await Promise.all([
    runtime.prompt({ sessionID: a.id, messageID: 'qwen-config-a', text: 'Reply with exactly: SESSION_A_OK. Do not use tools.' }),
    runtime.prompt({ sessionID: b.id, messageID: 'qwen-config-b', text: 'Reply with exactly: SESSION_B_OK. Do not use tools.' }),
  ]);
  const [aEnd, bEnd] = await Promise.all([aDone, bDone]);
  note('concurrent_session_prompts', { a: outcome(aEnd), b: outcome(bEnd), aHasReply: textOf(runtime, a.id).includes('SESSION_A_OK'), bHasReply: textOf(runtime, b.id).includes('SESSION_B_OK') });
  if (aEnd.outcome !== 'completed' || bEnd.outcome !== 'completed') throw new Error('Concurrent model prompt failed; later acceptance stages stopped');

  const approvalAsk = waitFor(runtime, (event) => event.type === 'permission-asked' && event.request?.value?.sessionID === a.id);
  const approvalDone = done(runtime, a.id);
  await runtime.prompt({ sessionID: a.id, messageID: 'qwen-config-grant', text: `Use the file writing tool to write exactly APPROVED_TOOL_OK to ${join(workspace, 'approved.txt')}. Do not answer until it is written.` });
  const ask = await approvalAsk;
  const request = ask.request.value;
  const allow = request.options.find((option) => option.kind === 'allow_once');
  if (!allow) throw new Error(`No allow_once option was advertised: ${JSON.stringify(request.options)}`);
  await runtime.reply(request.id, allow.optionId);
  const approved = await approvalDone;
  const approvedFile = await readFile(join(workspace, 'approved.txt'), 'utf8').catch(() => null);
  note('permission_grant_and_write', { completion: outcome(approved), fileContent: approvedFile, permissionKind: allow.kind });

  const rejectAsk = waitFor(runtime, (event) => event.type === 'permission-asked' && event.request?.value?.sessionID === a.id);
  const rejectDone = done(runtime, a.id);
  await runtime.prompt({ sessionID: a.id, messageID: 'qwen-config-reject', text: `Use the file writing tool to write exactly DENIED_TOOL_BAD to ${join(workspace, 'denied.txt')}.` });
  const rejectedRequest = (await rejectAsk).request.value;
  const reject = rejectedRequest.options.find((option) => option.kind === 'reject_once');
  if (!reject) throw new Error(`No reject_once option was advertised: ${JSON.stringify(rejectedRequest.options)}`);
  await runtime.reply(rejectedRequest.id, reject.optionId);
  const rejected = await rejectDone;
  const deniedFile = await readFile(join(workspace, 'denied.txt'), 'utf8').catch(() => null);
  note('permission_reject_and_write', { completion: outcome(rejected), fileCreated: deniedFile !== null, permissionKind: reject.kind });

  const stopAsk = waitFor(runtime, (event) => event.type === 'permission-asked' && event.request?.value?.sessionID === b.id);
  const stopDone = done(runtime, b.id);
  await runtime.prompt({ sessionID: b.id, messageID: 'qwen-config-stop', text: 'Use the terminal tool to run a 90-second sleep command and wait for it to finish. Do not answer until the command completes.' });
  const stopRequest = (await stopAsk).request.value;
  const stopAllow = stopRequest.options.find((option) => option.kind === 'allow_once');
  if (!stopAllow) throw new Error('No allow_once option for the long-running terminal tool');
  await runtime.reply(stopRequest.id, stopAllow.optionId);
  const stopCommand = done(runtime, b.id, 60000);
  const interruptedByCancel = waitFor(runtime, (event) => event.type === 'status' && event.sessionID === b.id && ['interrupted', 'failed'].includes(event.outcome), 60000);
  const toolStarted = waitFor(runtime, (event) => event.type === 'part-upsert' && runtime.messages(b.id).some((message) => message.parts.some((part) => part.type === 'tool' && part.state.status === 'running')), 60000).catch(() => null);
  const observed = await Promise.race([stopCommand.then((event) => ({ event })), toolStarted.then((event) => ({ tool: event }))]);
  if (observed.tool) await runtime.cancel(b.id);
  const stoppedTurn = observed.event ?? await interruptedByCancel;
  note('cancel_long_terminal_turn', { completion: outcome(stoppedTurn), cancelled: Boolean(observed.tool) });

  const beforeRestart = runtime.messages(a.id).length;
  await runtime.stop(); stopCalled = true; started = false;
  const descriptor = await start(); started = true; stopCalled = false;
  const restoredIds = runtime.sessions().map((session) => session.id);
  const reopened = await runtime.open(a.id);
  const historyDone = done(runtime, a.id);
  await runtime.prompt({ sessionID: a.id, messageID: 'qwen-config-resume', text: 'Continue the conversation and reply with exactly: HISTORY_RESTORED_OK.' });
  const historyEnd = await historyDone;
  note('restart_history_and_context', { reinitialized: descriptor.version, originalSessionsRestored: restoredIds.includes(a.id) && restoredIds.includes(b.id), savedMessages: beforeRestart, reopenedMessages: reopened.length, resumed: outcome(historyEnd), replyPresent: textOf(runtime, a.id).includes('HISTORY_RESTORED_OK') });
} catch (error) {
  result.errors.push({ message: error.message, stack: error.stack?.split('\n').slice(0, 5) });
} finally {
  try {
    await runtime.stop(); stopCalled = true;
    result.childExited = true;
  } catch (error) {
    result.errors.push({ stopError: error.message });
    result.childExited = false;
  }
  result.stopped = stopCalled;
  result.logs = log;
  await mkdir(root, { recursive: true });
  await writeFile(output, `${JSON.stringify(result, null, 2)}\n`, 'utf8');
  process.stdout.write(`${JSON.stringify({ output, tests: result.tests, errors: result.errors, stopped: result.stopped, childExited: result.childExited }, null, 2)}\n`);
}
