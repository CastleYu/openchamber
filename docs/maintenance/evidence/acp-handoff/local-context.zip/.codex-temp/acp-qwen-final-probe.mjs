import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { createAcpRuntime } from '../packages/web/server/lib/acp/runtime.js';

const home = 'D:/CodexBuilds/acp-real-validation/qwen-configured-test';
const workspace = join(home, 'workspace');
const output = join(process.cwd(), '.codex-temp/acp-qwen-final-probe.json');
const a = '84f8248a-836d-4314-b820-bc1b99bc602b';
const stamp = Date.now();
const pidPath = join(workspace, `cancel-${stamp}.pid`);
const latePath = join(workspace, `cancel-${stamp}.late`);
const result = { agent: 'Qwen Code', tests: {}, errors: [] };
const runtime = createAcpRuntime({ storagePath: join(home, 'acp-sessions.json') });
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const read = (path) => readFile(path, 'utf8').catch(() => null);
const alive = (pid) => { try { process.kill(pid, 0); return true; } catch (error) { if (error.code === 'ESRCH') return false; throw error; } };
const wait = (predicate, ms = 90000) => new Promise((resolve) => {
  const timer = setTimeout(() => { off(); resolve({ timeout: true }); }, ms);
  const off = runtime.subscribe((event) => {
    if (!predicate(event)) return;
    clearTimeout(timer); off(); resolve(event);
  });
});
const done = (id) => wait((event) => event.type === 'status' && event.sessionID === id && ['completed', 'interrupted', 'failed'].includes(event.outcome));
try {
  Object.assign(process.env, { QWEN_HOME: home, HOME: home, USERPROFILE: home, TEMP: join(workspace, 'temp'), TMP: join(workspace, 'temp') });
  if (!process.env.OPENCODE_GO_API_KEY) throw new Error('Missing injected Go key');
  const descriptor = await runtime.start({ command: process.execPath, args: [join(process.cwd(), '.codex-temp/acp-qwen-capture-configured.mjs'), '--acp', '--approval-mode', 'default', '--safe-mode'], cwd: workspace });
  result.version = descriptor.version;
  await runtime.open(a);
  const before = new Set(runtime.messages(a).map((message) => message.info.id));
  const historyDone = done(a);
  const recallPrompt = 'What exact marker did you output in your first assistant reply in this conversation? Reply with that marker only. Do not use tools.';
  await runtime.prompt({ sessionID: a, messageID: `qwen-final-recall-${stamp}`, text: recallPrompt });
  const recalled = await historyDone;
  const newReplies = runtime.messages(a).filter((message) => message.info.role === 'assistant' && !before.has(message.info.id)).map((message) => message.parts.filter((part) => part.type === 'text').map((part) => part.text).join(''));
  result.tests.fresh_runtime_context_recall = { sessionID: a, completion: recalled.outcome ?? null, error: recalled.error?.message ?? null, timedOut: Boolean(recalled.timeout), prompt: recallPrompt, newAssistantReplies: newReplies, passed: recalled.outcome === 'completed' && newReplies.join('').trim() === 'SESSION_A_OK' };
  const b = await runtime.createSession({ directory: workspace, title: 'Final process cancel probe' });
  const code = `const fs=require('node:fs');fs.writeFileSync(${JSON.stringify(pidPath)},String(process.pid));setTimeout(()=>fs.writeFileSync(${JSON.stringify(latePath)},'LATE'),60000)`;
  const command = `node -e ${JSON.stringify(code)}`;
  const askPromise = wait((event) => event.type === 'permission-asked' && event.request?.value?.sessionID === b.id);
  const endPromise = done(b.id);
  await runtime.prompt({ sessionID: b.id, messageID: `qwen-final-cancel-${stamp}`, text: `Use the terminal tool to execute this exact Node command, then wait for its completion. Do not substitute PowerShell sleep or a detached process. Command: ${command}` });
  const asked = await askPromise;
  if (asked.timeout) throw new Error('No terminal approval arrived');
  const request = asked.request.value;
  const allow = request.options.find((option) => option.kind === 'allow_once');
  if (!allow) throw new Error('Terminal approval lacked allow_once');
  result.tests.cancel_process = { sessionID: b.id, permissionKind: allow.kind, pidPath, latePath, toolCall: request.toolCall ?? null };
  await runtime.reply(request.id, allow.optionId);
  let pid = null;
  const deadline = Date.now() + 45000;
  while (Date.now() < deadline) {
    const value = await read(pidPath);
    if (value && /^\d+$/.test(value.trim())) { pid = Number(value.trim()); break; }
    await pause(250);
  }
  if (!pid) throw new Error('PID file not observed within 45 seconds after approval');
  const seen = Date.now();
  result.tests.cancel_process.pid = pid;
  result.tests.cancel_process.runningBeforeCancel = alive(pid);
  await runtime.cancel(b.id);
  const ended = await endPromise;
  await pause(1500);
  result.tests.cancel_process.completion = ended.outcome ?? null;
  result.tests.cancel_process.timedOut = Boolean(ended.timeout);
  result.tests.cancel_process.exitedAfterCancel = !alive(pid);
  await pause(Math.max(0, 62000 - (Date.now() - seen)));
  result.tests.cancel_process.lateFileExists = (await read(latePath)) !== null;
  result.tests.cancel_process.exitedAfterLateDeadline = !alive(pid);
  result.tests.cancel_process.observationMs = Date.now() - seen;
  result.tests.cancel_process.passed = ended.outcome === 'interrupted' && result.tests.cancel_process.runningBeforeCancel && result.tests.cancel_process.exitedAfterCancel && !result.tests.cancel_process.lateFileExists && result.tests.cancel_process.exitedAfterLateDeadline;
} catch (error) {
  result.errors.push({ message: error.message });
} finally {
  try { await runtime.stop(); result.stopped = true; } catch (error) { result.stopped = false; result.errors.push({ stopError: error.message }); }
  await writeFile(output, `${JSON.stringify(result, null, 2)}\n`, 'utf8');
  process.stdout.write(`${JSON.stringify({ output, ...result }, null, 2)}\n`);
}
