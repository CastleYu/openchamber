import { createAcpRuntime } from '../packages/web/server/lib/acp/runtime.js';
import { resolve } from 'node:path';
const home='D:/CodexBuilds/acp-real-validation/qwen-test';
Object.assign(process.env,{QWEN_HOME:home,HOME:home,USERPROFILE:home,TEMP:home+'/temp',TMP:home+'/temp'});
const runtime=createAcpRuntime();
try{
 await runtime.start({command:process.execPath,args:[resolve('.codex-temp/acp-qwen-capture.mjs'),'--acp','--approval-mode','default','--safe-mode'],cwd:home+'/workspace'});
 const s=await runtime.createSession({directory:home+'/workspace'});
 const done=new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Prompt timeout')),45000);runtime.subscribe(e=>{if(e.type==='status'&&e.sessionID===s.id&&e.outcome){clearTimeout(timer);resolve(e);}});});
 await runtime.prompt({sessionID:s.id,messageID:crypto.randomUUID(),text:'Reply exactly READY without tools.'});console.log(JSON.stringify(await done));
}finally{await runtime.stop();console.log('STOPPED');}
