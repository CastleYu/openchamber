import { mkdir, writeFile, readFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { createAcpRuntime } from '../packages/web/server/lib/acp/runtime.js';

const root = 'D:/CodexBuilds/acp-real-validation';
const home = join(root, 'qwen-test');
const workspace = join(home, 'workspace');
const output = join(root, 'qwen-real-run.json');
const cli = 'D:/CodexBuilds/acp-real-validation/qwen/node_modules/@qwen-code/qwen-code/cli-entry.js';
const log = [];
const result = { version: '0.25.1', tests: {}, errors: [] };
const note = (key, value) => { result.tests[key] = value; log.push({ key, value }); };
const waitFor = (runtime, predicate, timeout = 150000) => new Promise((resolveEvent, reject) => {
  const timer = setTimeout(() => { off(); reject(new Error(`timeout after ${timeout}ms`)); }, timeout);
  const off = runtime.subscribe((event) => {
    if (!predicate(event)) return;
    clearTimeout(timer); off(); resolveEvent(event);
  });
});
const done = (runtime, sessionID, timeout = 180000) => waitFor(runtime,
  (event) => event.type === 'status' && event.sessionID === sessionID && ['completed', 'interrupted', 'failed'].includes(event.outcome), timeout);
const outcome = (event) => ({ outcome: event.outcome, error: event.error?.message ?? null });
const selected = (runtime, sessionID, kind) => runtime.permissions().find((item) => item.value.sessionID === sessionID
  && item.value.options.some((option) => option.kind === kind));
const runtime = createAcpRuntime({ storagePath: join(home, 'acp-sessions.json') });
let stopCalled = false;
try {
  await mkdir(workspace, { recursive: true });
  process.env.QWEN_HOME = home;
  process.env.HOME = home;
  process.env.USERPROFILE = home;
  process.env.TEMP = join(home, 'temp');
  process.env.TMP = join(home, 'temp');
  await mkdir(process.env.TEMP, { recursive: true });
  if (!process.env.OPENAI_API_KEY || !process.env.OPENAI_BASE_URL || !process.env.OPENAI_MODEL) {
    throw new Error('Required OpenAI-compatible API environment variables are unavailable');
  }
  await writeFile(join(home, 'settings.json'), JSON.stringify({
    security: { auth: { selectedType: 'openai' } },
    model: { name: process.env.OPENAI_MODEL },
    modelProviders: { openai: [{ id: process.env.OPENAI_MODEL, name: 'Isolated validation model', envKey: 'OPENAI_API_KEY', baseUrl: process.env.OPENAI_BASE_URL }] },
  }, null, 2), 'utf8');
  const sessionStart = async () => runtime.start({ command: process.execPath, args: [cli, '--acp', '--approval-mode', 'default', '--safe-mode'], cwd: workspace });
  const connected = await sessionStart();
  const info = runtime.info();
  note('initialize', { descriptor: connected, agentInfo: info.agentInfo, agentCapabilities: info.agentCapabilities });
  const a = await runtime.createSession({ directory: workspace, title: 'Isolation A' });
  const b = await runtime.createSession({ directory: workspace, title: 'Isolation B' });
  note('multi_session', { ids: [a.id, b.id], distinct: a.id !== b.id });
  const aDone = done(runtime, a.id);
  await runtime.prompt({ sessionID: a.id, messageID: 'qwen-a-1', text: 'Reply with exactly: SESSION_A_OK. Do not use tools.' });
  const aEnd = await aDone;
  const bDone = done(runtime, b.id);
  await runtime.prompt({ sessionID: b.id, messageID: 'qwen-b-1', text: 'Reply with exactly: SESSION_B_OK. Do not use tools.' });
  const bEnd = await bDone;
  const textOf = (id) => runtime.messages(id).flatMap((message) => message.parts).filter((part) => part.type === 'text').map((part) => part.text).join('');
  note('independent_prompts', { a: outcome(aEnd), b: outcome(bEnd), aText: textOf(a.id), bText: textOf(b.id) });

  const ask = waitFor(runtime, (event) => event.type === 'permission-asked' && event.request?.value?.sessionID === a.id, 180000);
  const approvalDone = done(runtime, a.id, 240000);
  await runtime.prompt({ sessionID: a.id, messageID: 'qwen-a-tool', text: `Use the terminal tool to write the exact text APPROVED_TOOL_OK to ${join(workspace, 'approved.txt')}. Do not answer until the file is written.` });
  const asked = await ask;
  const request = asked.request.value;
  const allow = request.options.find((option) => option.kind === 'allow_once') ?? request.options.find((option) => option.kind.startsWith('allow_'));
  if (!allow) throw new Error(`No allow permission option advertised: ${JSON.stringify(request.options)}`);
  await runtime.reply(request.id, allow.optionId);
  const approvalEnd = await approvalDone;
  let approvedFile = null;
  try { approvedFile = await readFile(join(workspace, 'approved.txt'), 'utf8'); } catch {}
  note('permission_approval_and_tool', { options: request.options, chosen: allow.name, completion: outcome(approvalEnd), fileContent: approvedFile, toolParts: runtime.messages(a.id).flatMap((m) => m.parts).filter((p) => p.type === 'tool').map((p) => ({ title: p.title, status: p.state.status, output: p.state.output })) });

  const rejectAsk = waitFor(runtime, (event) => event.type === 'permission-asked' && event.request?.value?.sessionID === a.id, 180000);
  const rejectDone = done(runtime, a.id, 240000);
  await runtime.prompt({ sessionID: a.id, messageID: 'qwen-a-reject', text: `Use the terminal tool to write DENIED_TOOL_BAD to ${join(workspace, 'denied.txt')}.` });
  const rejectEvent = await rejectAsk;
  const rejectRequest = rejectEvent.request.value;
  const reject = rejectRequest.options.find((option) => option.kind === 'reject_once') ?? rejectRequest.options.find((option) => option.kind.startsWith('reject_'));
  if (!reject) throw new Error(`No reject permission option advertised: ${JSON.stringify(rejectRequest.options)}`);
  await runtime.reply(rejectRequest.id, reject.optionId);
  const rejectEnd = await rejectDone;
  let deniedExists = false;
  try { await readFile(join(workspace, 'denied.txt')); deniedExists = true; } catch {}
  note('permission_rejection', { options: rejectRequest.options, chosen: reject.name, completion: outcome(rejectEnd), deniedFileExists: deniedExists });

  const cancelDone = done(runtime, b.id, 240000);
  await runtime.prompt({ sessionID: b.id, messageID: 'qwen-b-cancel', text: 'Think carefully and provide a detailed 3000 word explanation of how to organize a small garden. Do not use tools.' });
  await new Promise((resolveDelay) => setTimeout(resolveDelay, 2500));
  const cancelAt = Date.now();
  await runtime.cancel(b.id);
  const cancelEnd = await cancelDone;
  note('cancel_active_generation', { completion: outcome(cancelEnd), cancelMs: Date.now() - cancelAt, status: runtime.statuses()[b.id] });

  await runtime.stop();
  stopCalled = true;
  await sessionStart();
  const restoredIds = runtime.sessions().map((session) => session.id);
  const restoredMessages = runtime.messages(a.id).length;
  const reopened = await runtime.open(a.id);
  const continueDone = done(runtime, a.id, 240000);
  await runtime.prompt({ sessionID: a.id, messageID: 'qwen-a-resume', text: 'Continue this conversation. Reply with exactly: HISTORY_RESTORED_OK.' });
  const continueEnd = await continueDone;
  note('history_restoration', { restoredIds, containsOriginal: restoredIds.includes(a.id) && restoredIds.includes(b.id), savedMessages: restoredMessages, openCount: reopened.length, resumedTurn: outcome(continueEnd), resumedText: textOf(a.id) });
} catch (error) {
  result.errors.push({ message: error.message, stack: error.stack?.split('\n').slice(0, 4) });
} finally {
  try { await runtime.stop(); stopCalled = true; } catch (error) { result.errors.push({ stopError: error.message }); }
  result.stopped = stopCalled;
  result.logs = log;
  await mkdir(root, { recursive: true });
  await writeFile(output, `${JSON.stringify(result, null, 2)}\n`, 'utf8');
  process.stdout.write(`${JSON.stringify({ output, tests: result.tests, errors: result.errors, stopped: result.stopped }, null, 2)}\n`);
}
