const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const root = process.cwd();
const dest = path.join(root, 'docs/maintenance/evidence/acp-handoff');
fs.mkdirSync(dest, { recursive: true });
const names = fs.readdirSync('.codex-temp').filter(n => /^acp-.*(results\.md|command-notes\.md)$/.test(n));
names.push('acp-parity-delivery.md', 'acp-parity-plan.md', 'acp-opencode-real.log', 'acp-opencode-stop.log',
  'acp-discovery-real.log', 'acp-grok-parity.log', 'acp-qwen-configured-run.json', 'acp-qwen-final-probe.json',
  'acp-parity-workspace-types.log', 'acp-parity-workspace-lint.log', 'acp-parity-dead-code.log',
  'acp-final-dual.log', 'acp-discovery-tests.log');
const secrets = Object.entries(process.env).filter(([k,v]) => /KEY|TOKEN|PASSWORD|SECRET/i.test(k) && v.length > 7).map(([,v])=>v);
for (const name of [...new Set(names)]) {
  const src = path.join('.codex-temp', name);
  if (!fs.existsSync(src)) continue;
  const text = fs.readFileSync(src, 'utf8');
  if (secrets.some(s => text.includes(s)) || /\b(?:sk-[A-Za-z0-9_-]{20,}|ghp_[A-Za-z0-9]{20,})\b/.test(text)) throw Error(`Secret candidate in ${name}`);
  fs.writeFileSync(path.join(dest, name.replace(/\.log$/, '.txt').replace(/\.md$/, '.txt')), text);
}
const carry = cp.execFileSync('git', ['ls-files', '--others', '--exclude-standard'], {encoding:'utf8'}).trim().split(/\r?\n/).filter(n =>
  /^\.tmp-.*\.cjs$/.test(n) || /^cagent-.*command-notes\.md$/.test(n) || n === 'int05-provider-owner-failures.md' || /\/legacy-provider-http(?:\.test)?\.js$/.test(n));
let patch = '';
for (const name of carry) {
  const text = fs.readFileSync(name, 'utf8');
  if (secrets.some(s => text.includes(s))) throw Error(`Secret candidate in ${name}`);
  const lines = text.replace(/\r\n/g, '\n').replace(/\n$/, '').split('\n');
  patch += `diff --git a/${name} b/${name}\nnew file mode 100644\n--- /dev/null\n+++ b/${name}\n@@ -0,0 +1,${lines.length} @@\n${lines.map(l=>'+'+l).join('\n')}\n`;
}
fs.writeFileSync(path.join(dest,'paused-5x-remnants.patch'), patch);
fs.writeFileSync('.codex-temp/acp-carryover-files.json', JSON.stringify(carry,null,2));
const readme = fs.readFileSync('README.md','utf8');
fs.writeFileSync('README.md', '> ACP handoff branch: [English README](README-ACP.md) | [中文说明](README-ACP.zh-CN.md)\n\n'+readme);
console.log(JSON.stringify({archived: names.length, carryover:carry, patchBytes:Buffer.byteLength(patch)}));
