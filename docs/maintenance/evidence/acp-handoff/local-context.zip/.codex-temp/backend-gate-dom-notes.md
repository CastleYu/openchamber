# BackendGate DOM test notes

- A search command used `web/server/lib/agent` from the repository root, but this project stores it under `packages/web/server/lib/agent`; the path was corrected before further inspection.
- The focused Bun test process received EPERM while reading the allowed dijiang-next checkout; oxlint completed successfully. Retry only the focused test with the narrow elevated command if sandbox policy allows.
- The first elevated focused run found the new test's server constants import one directory too high; corrected it to the same repository-relative location used by BackendGate.
- The next focused run showed the mount counter is cumulative; corrected retirement expectations to assert one mount followed by one unmount.
