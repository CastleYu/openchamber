2026-10-09: PowerShell command text was interpolated by the outer shell, causing a parser failure during locale file inventory. Use single-quoted -Command input or avoid PowerShell variables in subsequent commands.
2026-10-09: rg on Windows did not expand brace-list path syntax during locale anchor inspection. Use directory globs or pass concrete paths.
2026-10-09: Quoted wildcard path was passed literally to rg on Windows and failed. Use concrete file paths.
2026-10-09: Bulk apply_patch stopped because es.ts uses a different dict declaration anchor. No files were modified by that failed patch. Inspect actual declarations and apply using per-file anchors.
