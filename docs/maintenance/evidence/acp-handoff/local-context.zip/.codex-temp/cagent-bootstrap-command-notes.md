# CAgent bootstrap command notes

- 2026-10-09: A batched read guessed `packages/ui/eslint.config.js`, which does not exist. The command printed that read failure. Discover config paths with `rg --files --hidden` before reading them. No configuration was changed.
- Root lint found three authored Fast Refresh errors because lazy component declarations lived in entry modules. Move those declarations to a component-only export module and rerun lint; retain existing warnings as baseline.
- A search guessed nonexistent `packages/ui/src/lib/mobileRuntime.ts`; use discovered existing platform/runtime files instead.
- PowerShell rejected Bash-style brace expansion in a search path. Supply each path as a separate argument in PowerShell.
