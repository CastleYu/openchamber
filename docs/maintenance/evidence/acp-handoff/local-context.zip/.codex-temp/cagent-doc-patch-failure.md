# Documentation patch command note

2026-10-09: A multi-file apply_patch failed because the SPEC anchor used only the first two sentences of a longer paragraph. The patch was not applied. Recovery: use a verified complete line or a unique heading as the anchor, then check the resulting file. No shell or sandbox failure occurred.

2026-10-09: A documentation rg check used the default cdee worktree while the documents live in dijiang-next. It returned missing-path errors. Recovery: explicitly set dijiang-next as workdir for documentation reads and validation; use absolute cdee paths only for task logs.
