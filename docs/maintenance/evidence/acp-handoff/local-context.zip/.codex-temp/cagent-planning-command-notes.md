## 2026-10-09

- Conversation test review: the first root type/lint pass failed on fixture inferred optional undefined JSON properties, unsupported test shim matchers, incomplete inferred feature maps and prefer-const. Replace fixtures with named JsonValue return contracts and exhaustive parsed snapshots; UI type-check and focused tests subsequently passed. Two documentation patches failed exact-line matching because the sentence continued on the same physical line; use an entire existing line or a unique heading as patch context.

- Correction: host contracts are `.js` plus `.d.ts`, not `.ts`; failed guessed paths do not prove an absent host package. Primary verified the actual files. Discover paths and distinguish denied access from absence.
- A parallel test agent replaced this notes file while the primary appended to it; use a unique per-task note file or append preserving existing text. Apply-patch then failed its header match; reread only the affected header and correct the patch.
- Restored prior notes: default Vitest failed before tests with esbuild `spawn EPERM`; exact scoped retries passed. Default CIM process query was denied; a scoped read returned only matching validation process IDs. Log reads before lint/dead-code started found no files; wait for those stages. `adapter-loader.test.js` matched no test; actual `loader.test.js` passed separately.
- Context reads guessed a missing UI README and invalid textual `-TotalCount`; discover optional docs and use numeric bounds. Preserve complete asynchronous shell results instead of output alone. New conversation anti-slop rejected unknown parameters, conditional empty spreads and anonymous widened object typing; fix source directly.
- Default Bun refused reading this attached checkout and tsconfigs with `EPERM`; run the same focused checks with scoped checkout/process approval.

- `Get-Content` on `packages/web/server/lib/agent/dispatcher.ts`, `constants.ts`, and `features.ts` failed because those files are absent from the assigned `dijiang-next/openchamber` checkout. The checkout only exposed `packages/ui` and package manifests in `rg --files`; subsequent inspection should first confirm paths with `rg --files`.
- Confirming the same `packages/web/server/lib/agent` path in the `cdee/openchamber` checkout also failed: that directory is absent there as well.
