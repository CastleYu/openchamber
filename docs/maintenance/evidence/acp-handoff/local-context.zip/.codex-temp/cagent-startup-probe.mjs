import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = 'C:/Users/74756/.codex/worktrees/dijiang-next/openchamber';
const directory = await mkdtemp(path.join(os.tmpdir(), 'cagent-production-probe-'));
process.env.OPENCHAMBER_DATA_DIR = path.join(directory, 'data');
process.env.OPENCHAMBER_CHATS_DIR = path.join(directory, 'chats');
process.env.OPENCHAMBER_RELAY_HOST = 'off';
let controller;
const timeout = setTimeout(() => { console.error('PROBE_TIMEOUT'); process.exit(2); }, 60000);
try {
  const adapter = path.join(directory, 'adapter');
  await mkdir(adapter);
  const source = Buffer.from('export function createAdapter() { return { capabilities: {}, handlers: {} }; }');
  await writeFile(path.join(adapter, 'adapter.mjs'), source);
  const { agentArtifactDigest } = await import(pathToFileURL(`${root}/packages/web/server/lib/agent/artifacts.js`));
  const files = [{ path: 'adapter.mjs', bytes: source.length, digest: createHash('sha256').update(source).digest('hex') }];
  const { startWebUiServer } = await import(pathToFileURL(`${root}/packages/web/server/index.js`));
  controller = await startWebUiServer({ port: 0, host: '127.0.0.1', apiOnly: true, attachSignals: false,
    uiPassword: '', exitOnShutdown: false,
    agentBackend: { family: 'cagent', candidate: { directory: adapter,
      manifest: { version: 1, files, artifactDigest: agentArtifactDigest(files) },
      profile: { family: 'cagent', adapterID: 'synthetic-probe', adapterRevision: 'probe-r1', capabilityRevision: 'probe-c1' },
      connection: { connectionID: 'synthetic-probe', serverRevision: 'unverified-probe', baseURL: 'http://127.0.0.1:1/', headers: {}, ready: true, authorized: true } } } });
  const origin = `http://127.0.0.1:${controller.getPort()}`;
  const { AgentClient, AgentClientError } = await import(pathToFileURL(`${root}/packages/ui/src/lib/agent/client.ts`));
  const { AGENT_OPERATION, AGENT_ERROR } = await import(pathToFileURL(`${root}/packages/web/server/lib/agent/constants.js`));
  const client = new AgentClient({ getRuntimeKey: () => 'synthetic-probe', subscribe: () => () => {},
    fetch: (route, init) => fetch(new URL(String(route), origin), init) });
  try {
    const selected = await client.selection();
    assert.deepEqual(selected.selection, { family: 'cagent', revision: 1 });
    const snapshot = await client.inspect();
    assert.equal(snapshot.scope.identity.family, 'cagent');
    await assert.rejects(client.dispatch(snapshot.scope, AGENT_OPERATION.GET_DEFAULT_MODEL, { workspaceID: 'synthetic-workspace' }),
      error => error instanceof AgentClientError && error.code === AGENT_ERROR.UNVERIFIED);
  } finally { client.dispose(); }
  const runtimeResponse = await fetch(`${origin}/api/agent-backend/runtime`);
  assert.equal(runtimeResponse.status, 200);
  const runtime = await runtimeResponse.json();
  assert.equal(runtime.identity.family, 'cagent');
  assert.ok(Object.values(runtime.operations).every(row => row.available === false));
  const featureResponse = await fetch(`${origin}/api/agent-backend/features`);
  assert.equal(featureResponse.status, 200);
  const features = await featureResponse.json();
  assert.ok(Object.values(features.features).every(row => row.available === false));
  const refused = await fetch(`${origin}/api/config/agents`);
  assert.equal(refused.status, 501);
  assert.deepEqual(controller.getOpenCodeProcessInfo(), { managed: false, pid: null, port: null });
  console.log('PROBE_PASS: production loopback startup and shared client, protected CAgent family selection, unverified operation refused, all features closed, OpenCode config refused, no managed OpenCode process');
} catch (error) {
  process.exitCode = 1;
  console.error('PROBE_FAIL', error);
} finally {
  if (controller) await controller.stop({ exitProcess: false });
  clearTimeout(timeout);
  await rm(directory, { recursive: true, force: true });
}
