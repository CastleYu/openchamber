- 2026-10-08: g targeted nonexistent packages/ui/src/components/settings; use g --files packages/ui/src first and exact discovered paths.
