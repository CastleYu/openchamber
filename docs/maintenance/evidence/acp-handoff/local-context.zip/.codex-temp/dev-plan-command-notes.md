# DEV PLAN inspection command notes

- 2026-10-08: A source search in the new DIJIANG worktree used obsolete paths for SessionProjectScroller, SidebarActivitySections, and OpenCodeCliSettings. ripgrep reported missing paths. Discover current paths with `rg --files` before searching; DEV-PLAN source paths describe the older September tree.
- A memory search returned exit 1 with no matches. This is ripgrep's normal no-match result, not an environment failure.
