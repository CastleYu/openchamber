# Request journal task notes

- 2026-10-09: Running Bun from the `dijiang-next` checkout under the default sandbox failed with EPERM reading the test, checkout root, and tsconfig. This is a sandbox boundary issue; retry the same focused validation with scoped escalation.
