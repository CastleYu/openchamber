# Selection bootstrap command notes

2026-10-09

- An initial read guessed nonexistent `selection.js`; selection is owned by discovered `host.js`. Use `rg --files` first.
- Windows `rg` received literal wildcard paths `constants*`/`schemas*` and rejected them. Use a directory plus `-g` or explicit discovered files.
- A mixed note/source read accidentally selected cdee, where the new agent module is absent. All implementation reads and checks must explicitly use dijiang-next; cdee is only the writable task log location.
- Delegated test writer ignored the specified checkout and created two new test files in cdee with guessed APIs. Removed exactly those two newly created files; primary writes and validates the real tests in dijiang-next. Do not use that agent result as evidence.
- Focused Vitest startup hit esbuild spawn EPERM in the default sandbox. Repeat the same exact test with scoped process approval; this is infrastructure failure, not a test result.
- A task-log discovery in dijiang-next failed because task logs live in cdee. Use cdee only for known .codex-temp reads. A dead-code log scan while its writer was still running returned no matches; inspect after completion instead.
