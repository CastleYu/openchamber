const fs = require('node:fs');
const cp = require('node:child_process');
const tracked = cp.execFileSync('git',['diff','--name-only'],{encoding:'utf8'}).trim().split('\n');
const added = cp.execFileSync('git',['ls-files','--others','--exclude-standard'],{encoding:'utf8'}).trim().split('\n');
const carry = JSON.parse(fs.readFileSync('.codex-temp/acp-carryover-files.json','utf8'));
const files = [...new Set([...tracked,...added])].filter(n => n && !carry.includes(n));
for (const name of files) {
  if (!/^(README(?:-ACP(?:\.zh-CN)?)?\.md|docs\/maintenance\/|packages\/(?:ui|web)\/|\.github\/workflows\/acp-portable\.yml)/.test(name)) throw Error(`Unexpected file: ${name}`);
  const text = fs.readFileSync(name,'utf8');
  if (/\b(?:sk-[A-Za-z0-9_-]{20,}|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,})\b/.test(text) || /-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----/.test(text)) throw Error(`Secret candidate: ${name}`);
  for (const [key,value] of Object.entries(process.env)) {
    if (/KEY|TOKEN|PASSWORD|SECRET/i.test(key) && value.length > 7 && text.includes(value)) throw Error(`Environment secret candidate: ${name}`);
  }
}
fs.writeFileSync('.codex-temp/acp-stage-files.json',JSON.stringify(files,null,2));
cp.execFileSync('git',['add','--',...files],{stdio:'inherit'});
console.log(`Staged ${files.length} explicit files; ${carry.length} unrelated loose originals retained locally and archived as an inert patch.`);
